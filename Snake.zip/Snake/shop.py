import time
import tkinter
import pygame
import fos
import button
from PIL import Image, ImageTk
from PIL.ImageTk import PhotoImage
import Snake

class Shop:
    def __init__(self, surface):
        self.nobuy=True
        self.draw_button=True
        self.formel = int(surface.get_width() + surface.get_height() / 125)
        self.color = (255, 255, 255)
        self.schriftgroesse = int((surface.get_width() + surface.get_height()) / 71)
        self.smallfont = pygame.font.SysFont('italic', self.schriftgroesse)
        # draw the text
        def blit_text(surface, text, pos=(int(surface.get_width()) / 4 +20, int(surface.get_height()//2)), font=self.smallfont, color=pygame.Color('black'), mode="buttons"):
            words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
            space = font.size(' ')[0]  # The width of a space.
            if mode=="buttons":
                max_width, max_height = int(surface.get_width()) / 1.25, surface.get_height()
            else:
                max_width, max_height = 9999,9999
            x, y = pos
            for line in words:
                for word in line:
                    word_surface = font.render(word, 0, color)
                    word_width, word_height = word_surface.get_size()
                    if x + word_width >= max_width:
                        x = pos[0]  # Reset the x.
                        y += word_height  # Start on new row.
                    surface.blit(word_surface, (x, y))
                    x += word_width + space
                x = pos[0]  # Reset the x.
                y += word_height  # Start on new row.

        self.beschreibungstext="Du kannst alle beschrieben Skins für den gennanten Preis kaufen.\nDu kannst nur ein Set nach dem anderen Kaufen"
        self.text1 = ["Der Kopf ist blau, der Rest ist grün\nDer Kopf ist Rot, der Rest ist grün\nDer Kopf ist magenta, der Rest ist grün\n\nPreis: 200", 200]
        self.text2 = ["Jede 3. Kugel ist blau, der Rest ist grün\nJede 3. Kugel ist rot, der Rest ist grün\nJede 3. Kugel ist magenta, der Rest ist grün\n\nPreis: 300", 300]
        self.text3 = ["Jede 2. Kugel ist blau, der Rest ist grün\nJede 2. Kugel ist rot, der Rest ist grün\nJede 2. Kugel ist magenta, der Rest ist grün\n\nPreis: 400", 400]
        self.text4 = ["Die komplette Snake ist blau\nDie komplette Snake ist rot\nDie komplette Snake ist magenta\n\nPreis: 500", 500]
        self.text5 = ["Jede 3. Kugel hat eine zufällige Farbe, der Rest ist blau\nJede 3. Kugel hat eine zufällige Farbe, der Rest ist rot\nJede 3. Kugel hat eine zufällige Farbe, der Rest ist magenta\n\nPreis: 600", 600]
        self.text6 = ["Jede 2. Kugel hat eine zufällige Farbe, der Rest ist blau\nJede 2. Kugel hat eine zufällige Farbe, der Rest ist rot\nJede 2. Kugel hat eine zufällige Farbe, der Rest ist magenta\n\nPreis: 700", 700]
        self.text7 = ["Jede Kugel der Snake hat eine zufällige Farbe\nJede Kugel der Snake hat eine zufällige Farbe, welche bei jeder Bewegung wechselt\n\nPreis: 1000", 1000]

        self.page=1
        self.maxpage=7
        self.minpage=1
        # defining a font

        try:
            self.money = int(fos.Read.do())
        except IndexError:
            self.money = "ERROR"
            time.sleep(5)
            sys.exit("MONEY SYSTEM FAILED")
        try:
            self.rang = int(fos.Read.do(line=1))
        except IndexError:
            self.rang = "ERROR"
            time.sleep(5)
            sys.exit("RANG SYSTEM FAILED")

        self.text_money = f"Du hast {self.money}"
        a = self.smallfont.render(self.text_money, (0, 0), (255,255,255))
        textRect = a.get_rect()
        textRect.topleft = (0, 0)

        # loading pictures
        beenden_img = pygame.image.load(r"bilder\x.png").convert_alpha()
        beenden2_img = pygame.image.load(r"bilder\x2.png").convert_alpha()
        buy_img = pygame.image.load(r"bilder\buy.png").convert_alpha()
        buy2_img = pygame.image.load(r"bilder\buy2.png").convert_alpha()
        buy3_img = pygame.image.load(r"bilder\buy3.png").convert_alpha()

        links_img = pygame.image.load(r"bilder\button_links.png").convert_alpha()
        rechts_img = pygame.image.load(r"bilder\button_rechts.png").convert_alpha()
        links2_img = pygame.image.load(r"bilder\button_links2.png").convert_alpha()
        rechts2_img = pygame.image.load(r"bilder\button_rechts2.png").convert_alpha()

        #loading buttons
        close_button = button.Button(int(surface.get_width()) / 2, int(surface.get_height()), beenden_img,
                                  (self.formel / 1000),4)
        close_button2 = button.Button(int(surface.get_width()) / 2, int(surface.get_height()), beenden2_img,
                                   (self.formel / 1000),4)

        buy_button = button.Button(int(surface.get_width()) / 2, int(surface.get_height() / 1.1), buy_img,
                                   (self.formel / 1000), 4)
        buy2_button = button.Button(int(surface.get_width()) / 2, int(surface.get_height() / 1.1), buy2_img,
                                    (self.formel / 1000), 4)
        buy3_button = button.Button(int(surface.get_width()) / 2, int(surface.get_height() / 1.1), buy3_img,
                                    (self.formel / 1000), 4)

        links_button = button.Button(int(surface.get_width()) / 4, int(surface.get_height()//2), links_img,
                                     (self.formel / 1000), 2)
        links2_button = button.Button(int(surface.get_width()) / 4, int(surface.get_height()//2), links2_img,
                                      (self.formel / 1000), 2)
        rechts_button = button.Button(int(surface.get_width()) / 1.25, int(surface.get_height()//2), rechts_img,
                                     (self.formel / 1000), 6)
        rechts2_button = button.Button(int(surface.get_width()) / 1.25, int(surface.get_height()//2), rechts2_img,
                                      (self.formel / 1000), 6)

        shop=True
        while shop:
            surface.fill((25, 50, 10))
            blit_text(surface=surface, text=self.beschreibungstext, mode="full", pos=(surface.get_height()//2,100), color=pygame.Color("blue"))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    shop = False
                    Snake.Main()
                    break

            if close_button.draw(surface)[0]:
                Snake.Main()
                shop = False
            if close_button.draw(surface)[1]:
                close_button2.draw(surface)

            if not self.nobuy:
                if self.draw_button:
                    if buy_button.draw(surface)[0]:
                        fos.Write.do(value=1, line=1)
                        if self.page!=8:
                            fos.Write.do(value=int(self.page+1)*100, line=0, mode="min")
                        else:
                            fos.Write.do(value=1000, line=0, mode="min")
                        Snake.Main()
                        shop = False
                        break
                    if buy_button.draw(surface)[1]:
                        buy2_button.draw(surface)

            if links_button.draw(surface, secure=True)[0]:
                if not self.page==self.minpage:
                    self.page-=1
                print(self.page)

            if links_button.draw(surface)[1]:
                links2_button.draw(surface)

            if rechts_button.draw(surface, secure=True)[0]:
                if not self.page==self.maxpage:
                    self.page+=1
                print(self.page)
            if rechts_button.draw(surface)[1]:
                rechts2_button.draw(surface)
#==============================================#==============================
            if self.page==1:
                if self.page<self.rang:
                    self.draw_button=False
                else:
                    self.draw_button=True
                blit_text(surface=surface, text=self.text1[0])
                if self.draw_button:
                    if (int(self.money)<self.text1[1]) or (int(self.rang)<1):
                        buy3_button.draw(surface)
                        self.nobuy=True
                    else:
                        self.nobuy=False
            elif self.page == 2:
                if self.page<self.rang:
                    self.draw_button=False
                else:
                    self.draw_button=True
                blit_text(surface=surface, text=self.text2[0])
                if self.draw_button:
                    if (int(self.money)<self.text2[1]) or (int(self.rang)<2):
                        buy3_button.draw(surface)
                        self.nobuy=True
                    else:
                        self.nobuy=False
            elif self.page==3:
                if self.page<self.rang:
                    self.draw_button=False
                else:
                    self.draw_button=True
                blit_text(surface=surface, text=self.text3[0])
                if self.draw_button:
                    if (int(self.money)<self.text3[1]) or (int(self.rang)<3):
                        buy3_button.draw(surface)
                        self.nobuy=True
                    else:
                        self.nobuy=False
            elif self.page==4:
                if self.page<self.rang:
                    self.draw_button=False
                else:
                    self.draw_button=True
                blit_text(surface=surface, text=self.text4[0])
                if self.draw_button:
                    if (int(self.money)<self.text4[1]) or (int(self.rang)<4):
                        buy3_button.draw(surface)
                        self.nobuy=True
                    else:
                        self.nobuy=False
            elif self.page==5:
                if self.page<self.rang:
                    self.draw_button=False
                else:
                    self.draw_button=True
                blit_text(surface=surface, text=self.text5[0])
                if self.draw_button:
                    if (int(self.money)<self.text5[1]) or (int(self.rang)<5):
                        buy3_button.draw(surface)
                        self.nobuy=True
                    else:
                        self.nobuy=False
            elif self.page==6:
                if self.page<self.rang:
                    self.draw_button=False
                else:
                    self.draw_button=True
                blit_text(surface=surface, text=self.text6[0])
                if self.draw_button:
                    if (int(self.money)<self.text6[1]) or (int(self.rang)<6):
                        buy3_button.draw(surface)
                        self.nobuy=True
                    else:
                        self.nobuy=False
            elif self.page==7:
                if self.page<self.rang:
                    self.draw_button=False
                else:
                    self.draw_button=True
                blit_text(surface=surface, text=self.text7[0])
                if self.draw_button:
                    if (int(self.money)<self.text7[1]) or (int(self.rang)<7):
                        buy3_button.draw(surface)
                        self.nobuy=True
                    else:
                        self.nobuy=False

            surface.blit(a, textRect)#Money
            pygame.display.update()


if __name__ == '__main__':
    Contact()
