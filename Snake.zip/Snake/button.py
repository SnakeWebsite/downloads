import pygame


class Button:
    def __init__(self, x, y, image, buttonScale, anderherum=0):


        width = image.get_width()
        height = image.get_height()

        self.image = pygame.transform.scale(image, (int(width * buttonScale), int(height * buttonScale)))
        self.rect = self.image.get_rect()

        if anderherum == 0:
            self.rect.topleft = (x, y)
        elif anderherum == 1:
            self.rect.topright = (x, y)
        elif anderherum == 2:
            self.rect.midright = (x, y)
        elif anderherum == 3:
            self.rect.midtop = (x, y)
        elif anderherum == 4:
            self.rect.midbottom = (x, y)
        elif anderherum == 5:
            self.rect.center = (x, y)
        elif anderherum == 6:
            self.rect.midleft = (x, y)
        elif anderherum == 7:
            self.rect.bottomleft = (x,y)
        elif anderherum == 8:
            self.rect.bottomright = (x,y)
        self.block=True


    def draw(self, surface, secure=False):
        self.clicked = False
        action = False
        action2 = False
        pos = pygame.mouse.get_pos()

        if secure:
        # check mouseover and clicked conditions
            if self.rect.collidepoint(pos):
                action2=True
                if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                    self.block=False
                    self.clicked = True


            if pygame.mouse.get_pressed()[0] == 0 and self.block==False:
                self.clicked = False
                self.block=True
                action = True
        else:
            # check mouseover and clicked conditions
            if self.rect.collidepoint(pos):
                action2=True
                if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                    self.clicked = True
                    action = True

            if pygame.mouse.get_pressed()[0] == 0:
                self.clicked = False

        surface.blit(self.image, (self.rect.x, self.rect.y))
        return action, action2
