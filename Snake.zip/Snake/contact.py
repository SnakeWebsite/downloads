import threading
import tkinter.messagebox
import messages
import pygame
import smtplib
import button
from multiprocessing import Process

tempy = 0


class Contact:

    def __init__(self, surface):


        # defining a font
        schriftgroesse = int((surface.get_width() + surface.get_height()) / 71)
        print(schriftgroesse)
        smallfont = pygame.font.SysFont('italic', schriftgroesse)

        formel = int(surface.get_width() + surface.get_height() / 125)

        # userInput
        userInput = "|"
        inputRect = pygame.Rect(50, int(surface.get_height() / 2.5), surface.get_width() - 100,
                                surface.get_width() * 0.2)

        # include pictures
        symbol = pygame.image.load("bilder\Tobias Logo.png").convert_alpha()
        symbol2 = pygame.image.load("bilder\snake.png").convert_alpha()

        beenden_img = pygame.image.load(r"bilder\x.png").convert_alpha()
        beenden2_img = pygame.image.load(r"bilder\x2.png").convert_alpha()

        send_img = pygame.image.load("bilder\send.png").convert_alpha()
        send2_img = pygame.image.load("bilder\send2.png").convert_alpha()

        textInfo1 = smallfont.render('Nachricht senden:', True, (255, 100, 0))
        textInfo2 = smallfont.render("Hier kannst du mir Nachrichten senden. Sie können allgemeines Feedback, "
                                     "Bugs oder alles andere enthalten.", True, (145, 200, 30))
        textInfo3 = smallfont.render("Beachte, dass ich für Rückmeldungen deine "
                                     "E-Mail Adresse oder Discordname brauche.", True, (145, 200, 30))

        # define a better blit function
        temp = pygame.draw.rect(surface, pygame.Color("lightskyblue3"), inputRect, 2)

        # ----------------------------------------------
        def blit_text(surface, text, pos, font=smallfont, color=pygame.Color('black')):
            words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
            space = font.size(' ')[0]  # The width of a space.
            max_width, max_height = temp.width, temp.height
            x, y = pos
            for line in words:
                for word in line:
                    word_surface = font.render(word, 0, color)
                    word_width, word_height = word_surface.get_size()
                    if x + word_width >= max_width:
                        x = pos[0]  # Reset the x.
                        y += word_height  # Start on new row.
                    surface.blit(word_surface, (x, y))
                    x += word_width + space
                x = pos[0]  # Reset the x.
                y += word_height  # Start on new row.

        # -----------------------------------------------

        # symbols for corners
        symbol_button = button.Button(0,0, symbol,
                                      (formel / 5000), 0)
        symbol_button2 = button.Button(int(surface.get_width()), 0, symbol, (formel / 5000), 1)
        symbol_button3 = button.Button(0, int(surface.get_height()), symbol2,
                                       (formel / 700), 7)
        symbol_button4 = button.Button(int(surface.get_width()), int(surface.get_height()), symbol2,
                                       (formel / 700), 8)

        ok_button = button.Button(int(surface.get_width()) / 2, int(surface.get_height() / 1.2), beenden_img,
                                  (formel / 1000))
        ok_button2 = button.Button(int(surface.get_width()) / 2, int(surface.get_height() / 1.2), beenden2_img,
                                   (formel / 1000))

        send_button = button.Button(int(surface.get_width()) / 1.8, int(surface.get_height() / 1.2), send_img,
                                    (formel / 5000))
        send2_button = button.Button(int(surface.get_width()) / 1.8, int(surface.get_height() / 1.2), send2_img,
                                    (formel / 5000))
        # symbols
        textRectInfo1 = textInfo1.get_rect()
        textRectInfo2 = textInfo2.get_rect()
        textRectInfo3 = textInfo3.get_rect()
        surface.fill((25, 50, 10))

        textRectInfo1.center = (int(surface.get_width()) / 2, int(surface.get_height() / 5))
        textRectInfo2.center = (int(surface.get_width()) / 2, int(surface.get_height() / 3.5))
        textRectInfo3.center = (int(surface.get_width()) / 2, (textRectInfo2[1] + schriftgroesse * 1.5))

        # loop
        infos = True
        while infos:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    infos = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        userInput = f"{userInput[:-2]}|"
                    else:
                        # userInput += event.unicode
                        userInput = f"{userInput}{event.unicode}".replace("|", "")
                        userInput += "|"

            surface.fill((25, 50, 10))
            if ok_button.draw(surface)[0]:
                infos = False
            if ok_button.draw(surface)[1]:
                ok_button2.draw(surface)
            if send_button.draw(surface)[0]:
                messages.doAktionEmail(userInput, surface)
                infos = False
            if send_button.draw(surface)[1]:
                send2_button.draw(surface)


            # Buttons
            symbol_button.draw(surface)
            symbol_button2.draw(surface)
            symbol_button3.draw(surface)
            symbol_button4.draw(surface)

            # text
            surface.blit(textInfo1, textRectInfo1)
            surface.blit(textInfo2, textRectInfo2)
            surface.blit(textInfo3, textRectInfo3)

            # userInput
            text_surface = smallfont.render(userInput, True, (255, 255, 255))
            blit_text(surface=surface, text=userInput, pos=(inputRect.x + 5, inputRect.y + 5))
            # surface.blit(text_surface, (inputRect.x + 5, inputRect.y + 5))
            pygame.draw.rect(surface, pygame.Color("lightskyblue3"), inputRect, 2)

            pygame.display.update()
