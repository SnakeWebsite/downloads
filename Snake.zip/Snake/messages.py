import sys
import threading
import pygame
import smtplib
import Snake
import button


class Messages:
    def __init__(self, surface, message_sort, message_title, message, exit_to_menue=True, forced_exit=False, opt_args=None):
        # defining a font
        def blit_text(color=pygame.Color('black')):
            text = message
            pos = (self.surface.get_width() * 0.1, self.surface.get_height() * 0.5)
            font = self.smallfont

            words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
            space = font.size(' ')[0]  # The width of a space.
            max_width, max_height = surface.get_width(), surface.get_height()
            x, y = pos
            for line in words:
                for word in line:
                    word_surface = font.render(word, 0, color)
                    word_width, word_height = word_surface.get_size()
                    if x + word_width >= max_width:
                        x = pos[0]  # Reset the x.
                        y += word_height  # Start on new row.
                    surface.blit(word_surface, (x, y))
                    x += word_width + space
                x = pos[0]  # Reset the x.
                y += word_height  # Start on new row.
        self.surface = surface
        self.formel = int(surface.get_width() + surface.get_height() / 125)
        schriftgroesse = int((surface.get_width() + surface.get_height()) / 71)

        biggerfont = pygame.font.SysFont('italic', int(schriftgroesse * 3))
        middlefont = pygame.font.SysFont('italic', schriftgroesse * 2)
        self.smallfont = pygame.font.SysFont('italic', schriftgroesse)

        self.title = ""
        self.smalltitle = ""
        # loading pictures
        beenden_img = pygame.image.load(r"bilder\x.png").convert_alpha()
        beenden2_img = pygame.image.load(r"bilder\x.png").convert_alpha()
        beenden2_img.fill((255, 0, 0), special_flags=pygame.BLEND_RGB_ADD)

        # loading buttons
        close_button = button.Button(int(surface.get_width()) / 2, int(surface.get_height()), beenden_img,
                                     (self.formel / 1000), 4)
        close_button2 = button.Button(int(surface.get_width()) / 2, int(surface.get_height()), beenden2_img,
                                      (self.formel / 1000), 4)

        message_loop = True
        while message_loop:
            if message_sort == "error":
                surface.fill("#8B0000")
                self.title = biggerfont.render("Es ist ein unerwarteter Fehler aufgetreten!", True, "white")
            elif message_sort == "info":
                surface.fill("#80D000")
                self.title = biggerfont.render("Aktion erfolgreich durchgeführt!", True, "white")
            elif message_sort == "aktionEmail":
                surface.fill((0, 0, 255))
                self.title = biggerfont.render("Aktion wird durchgeführt!", True, "white")
            else:
                sys.exit("Error: Unknown message_sort: " + message_sort)  # exit
            self.smalltitle = middlefont.render(message_title, True, (68, 78, 255))
            self.smalltitle_rect = self.smalltitle.get_rect()
            self.smalltitle_rect.midtop = (int(surface.get_width()) / 2, int(surface.get_height() * 0.2))
            self.title_rect = self.title.get_rect()
            self.title_rect.midtop = (int(surface.get_width()) / 2, 0)
            surface.blit(self.title, self.title_rect)
            surface.blit(self.smalltitle, self.smalltitle_rect)
            blit_text()

            if not message_sort=="aktionEmail":
                if close_button.draw(surface, secure=True)[0]:
                    if exit_to_menue:
                        Snake.Main()
                    elif forced_exit:
                        sys.exit("Forced Exit")
                    break
                if close_button.draw(surface)[1]:
                    close_button2.draw(surface)
                for event in pygame.event.get():  # Check events
                    if event.type == pygame.QUIT:
                        message_loop = False
                        Snake.Main()
                        break  # Quite the loop here and returns to main loop
            pygame.display.update()
            if message_sort=="aktionEmail":
                doAktionEmail.email(opt_args[0], opt_args[1])
                print("Bitte nur 1")
                Messages(opt_args[1], "info", "Feedback erfolgreich gesendet", "Du hast dein Feedback erfolgreich gesendet!\nVielen Dank, dass du dir dafür Zeit genommen hast. :-}\n\n"
                                                                "Viel Spaß beim weiterem Spielen!")

class doAktionEmail():
    def __init__(self, text, surface):
        Messages(surface, "aktionEmail", "Feedback wird versendet", "Bitte warte bis deine Nachricht versendet wurde!\n\n"
                                                                    "Sobald sie erfolgreich versendet wurde, bekommst du eine Meldung\n\n\nDieser Vorgang kann bis zu 30 sekunden dauern", opt_args=[text, surface])
    @staticmethod
    def email(text, surface):
        try:
            SMTP_SERVER = "smtp.gmail.com"
            SMTP_PORT = 587
            SMTP_USERNAME = "snake.response@gmail.com"
            SMTP_PASSWORD = "smizwtekqlubdeyu"
            EMAIL_FROM = "snake.response@gmail.com"
            EMAIL_TO = "snake.response@gmail.com"
            EMAIL_SUBJECT = f"Ein neues Feedback von <<<Snake BETA {Snake.version}>>>"
            EMAIL_MESSAGE = text
            # EMAIL_MESSAGE = EMAIL_MESSAGE
            print("login")
            s = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
            s.starttls()
            s.login(SMTP_USERNAME, SMTP_PASSWORD)
            message = 'Subject: {}\n\n{}'.format(EMAIL_SUBJECT, EMAIL_MESSAGE)
            message = message.encode("UTF-8")
            print("fast ok")
            s.sendmail(EMAIL_FROM, EMAIL_TO, message)
            print("Ok")
        except Exception as e:
            print("Noop  ", e)
            Messages(surface=surface,message_sort="error",message_title="Fehler beim Feedback versenden",
                                         message="Es ist beim versenden des Feedbacks ist ein Fehler aufgetreten!\n"
                                                 "Bitte überprüfe deine Internetverbindung und probiere es erneut!\n\n"
                                                 "Falls der Fehler häufiger auftreten sollte, kontaktiere mich über "
                                                 f"Discord und gebe den folgenden Fehlercode an:\n{e}")
        finally:
            try:
                print("try Quit!")
                s.quit()
                print("succes quit")
            except Exception as e:
                print("lol ", e)
                pass
