import messages
import urllib.request
from Snake import version
print(version)
print("getting version...")
new_version = urllib.request.urlopen("https://raw.githubusercontent.com/SnakeWebsite/downloads/main/version.txt").read()
print("Done...")
new_version = float(new_version)
print(new_version)