import messages
import pygame
import Snake
import button
import fos
import messages
from PIL import Image, ImageEnhance
import time

class SkinSystem:
    # draw the text
    def blit_text(self, surface, text, pos, font, color=pygame.Color('black')):
        words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
        space = font.size(' ')[0]  # The width of a space.
        max_width, max_height = abs(self.buttons[0].rect.x-10), surface.get_height()
        x, y = pos
        for line in words:
            for word in line:
                word_surface = font.render(word, 0, color)
                word_width, word_height = word_surface.get_size()
                if x + word_width >= max_width:
                    x = pos[0]  # Reset the x.
                    y += word_height  # Start on new row.
                surface.blit(word_surface, (x, y))
                x += word_width + space
            x = pos[0]  # Reset the x.
            y += word_height  # Start on new row.

    def __init__(self, surface):

        self.formel = int(surface.get_width() + surface.get_height() / 125)
        self.color = (255, 255, 255)
        self.schriftgroesse = int((surface.get_width() + surface.get_height()) / 71)
        print(self.schriftgroesse)
        self.smallfont = pygame.font.SysFont('italic', self.schriftgroesse)

        # self.locked=False
        self.bilder=[]
        self.bilder2=[]
        self.buttons=[]
        self.buttons2=[]
        self.infos = [
            "Die komplette Snake ist grün",

            "Der Kopf ist blau, der Rest ist grün",
            "Der Kopf ist Rot, der Rest ist grün",
            "Der Kopf ist magenta, der Rest ist grün",

            "Jede 3. Kugel ist blau, der Rest ist grün",
            "Jede 3. Kugel ist rot, der Rest ist grün",
            "Jede 3. Kugel ist magenta, der Rest ist grün",

            "Jede 2. Kugel ist blau, der Rest ist grün",
            "Jede 2. Kugel ist rot, der Rest ist grün",
            "Jede 2. Kugel ist magenta, der Rest ist grün",

            "Die komplette Snake ist blau",
            "Die komplette Snake ist rot",
            "Die komplette Snake ist magenta",

            "Jede 3. Kugel hat eine zufällige Farbe, der Rest ist blau",
            "Jede 3. Kugel hat eine zufällige Farbe, der Rest ist rot",
            "Jede 3. Kugel hat eine zufällige Farbe, der Rest ist magenta",

            "Jede 2. Kugel hat eine zufällige Farbe, der Rest ist blau",
            "Jede 2. Kugel hat eine zufällige Farbe, der Rest ist rot",
            "Jede 2. Kugel hat eine zufällige Farbe, der Rest ist magenta",

            "Jede Kugel der Snake hat eine zufällige Farbe",
            "Jede Kugel der Snake hat eine zufällige Farbe, welche bei jeder Bewegung wechselt"
        ]
        try:
            self.rang = int(fos.Read.do(line=1))
        except IndexError:
            messages.Messages(surface, "error", "Fehler beim Lesen", "Bitte kontaktierem mich über Discord!\n"
                                                                     "Deine gespeicherten Beutzerdaten sind beschädigt!")
        if self.rang==1:
            self.skin_auflistung=1
        elif self.rang==2:
            self.skin_auflistung=4
        elif self.rang==3:
            self.skin_auflistung=7
        elif self.rang==4:
            self.skin_auflistung=10
        elif self.rang==5:
            self.skin_auflistung=13
        elif self.rang==6:
            self.skin_auflistung=16
        elif self.rang==7:
            self.skin_auflistung=19
        elif self.rang==8:
            self.skin_auflistung=21
        else:
            messages.Messages(surface, "error", "Fehler beim Lesen", "Bitte kontaktierem mich über Discord!\n"
                                                                     "Deine gespeicherten Beutzerdaten sind beschädigt!")
        # defining a font
        schriftgroesse = int((surface.get_width() + surface.get_height()) / 71)
        print(schriftgroesse)
        smallfont = pygame.font.SysFont('italic', schriftgroesse)
        self.formel = int(surface.get_width() + surface.get_height() / 125)

        # loading pictures
        beenden_img = pygame.image.load(r"bilder\x.png").convert_alpha()
        beenden2_img = pygame.image.load(r"bilder\x.png").convert_alpha()
        beenden2_img.fill((255, 0, 0), special_flags=pygame.BLEND_RGB_ADD)

        for i in range(1, 22):
            self.bilder.append(pygame.image.load(f"bilder\snakes\\{i}.png").convert_alpha())
            image=pygame.image.load(f"bilder\snakes\\{i}.png").convert_alpha()
            image.fill((120, 120, 120), special_flags=pygame.BLEND_RGB_ADD)
            self.bilder2.append(image)

        print(self.bilder)
        #loading buttons
        close_button = button.Button(int(surface.get_width()) / 2, int(surface.get_height()), beenden_img,
                                  (self.formel / 1000),4)
        close_button2 = button.Button(int(surface.get_width()) / 2, int(surface.get_height()), beenden2_img,
                                   (self.formel / 1000),4)
        self.index_loop_buttons=0
        for i in range(1, 11):
            self.buttons.append(
                button.Button(int(surface.get_width()) / 2, 100 + (self.index_loop_buttons * 50), self.bilder[i - 1],
                              (self.formel / 1000), 4)
            )
            self.buttons2.append(
                button.Button(int(surface.get_width()) / 2, 100 + (self.index_loop_buttons * 50), self.bilder2[i - 1],
                              (self.formel / 1000), 4)
            )
            self.index_loop_buttons += 1

        self.index_loop_buttons=0
        for i in range(11,22):
            self.buttons.append(
                button.Button(int(surface.get_width()) / 1.2-50,100+(self.index_loop_buttons*50), self.bilder[i-1],
                              (self.formel / 1000),4)
            )
            self.buttons2.append(
                button.Button(int(surface.get_width()) / 1.2-50,100+(self.index_loop_buttons*50), self.bilder2[i-1],
                              (self.formel / 1000),4)
            )
            self.index_loop_buttons+=1


        skin=True
        a = self.smallfont.render("Bitte wähle einen deiner verfügbaren Skins aus", (0, 0), self.color)
        textRect = a.get_rect()
        textRect.midtop = (surface.get_width()/2, 0)
        while skin:
            surface.fill((25, 50, 10))
            surface.blit(a, textRect)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    shop = False
                    Snake.Main()
                    break
            if close_button.draw(surface, secure=True)[0]:
                Snake.Main()
                shop = False
            if close_button.draw(surface)[1]:
                close_button2.draw(surface)
            for i in range(0,self.skin_auflistung):
                print(i)
                if self.buttons[i].draw(surface, secure=True)[0]:
                    fos.Write.do(mode="replace", value=i+1, line=2)
                    skin=False
                    Snake.Main()
                    break
                if self.buttons[i].draw(surface)[1]:
                    self.buttons2[i].draw(surface)
                    self.blit_text(surface, self.infos[i], (20, 100), self.smallfont, color=self.color)
            pygame.display.update()


if __name__ == '__main__':
    pass
