import sys
import os
file =["bilder\modules.dll"]
### 1:      Money
### 2:      RANK
### 3:      SKIN
### 4:      HIGHSCORE
class Oho:
    def __init__(self):
        sys.exit("HACKING DETECTED")

class Write:
    @staticmethod
    def do(value, line=0, mode="add"):
        data=[]
        data=Read.do(all=True)
        temp=data[line]
        temp.replace("\n","")
        temp=int(temp)
        if mode=="add":
             temp += value
        elif mode=="min":
            temp -= value
        elif mode=="replace":
            temp = value
        elif mode=="highest":
            if temp<value:
                temp=value
        temp=str(temp)
        data[line]=(temp+"\n")
        with open(file[0], 'r+') as f:
            f.writelines(data)

class Read:
    @staticmethod
    def do(line=0, all=False):
        data=[]
        returnValue = "Fehler beim Lesen der Datei!"
        with open(file[0], 'r') as f:
            data = f.readlines()
            if not all:
                returnValue=data[line].replace("\n","")
                returnValue.replace("\n","")
            else:
                returnValue=data
        return returnValue


if __name__ == '__main__':
    print(type(Read.do(line=2)))
