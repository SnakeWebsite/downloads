import pygame
import button


class Credits:
    def __init__(self, surface, version, color):
        formel = int(surface.get_width() + surface.get_height() / 125)
        # defining a font
        schriftgroesse = int((surface.get_width() + surface.get_height()) / 71)
        print(schriftgroesse)
        smallfont = pygame.font.SysFont('italic', schriftgroesse)

        # include pictures
        symbol = pygame.image.load("bilder\Tobias Logo.png").convert_alpha()
        symbol2 = pygame.image.load("bilder\snake.png").convert_alpha()

        beenden_img = pygame.image.load(r"bilder\x.png").convert_alpha()
        beenden2_img = pygame.image.load(r"bilder\x2.png").convert_alpha()

        infos = True
        textInfo1 = smallfont.render('INFORMATIONEN:', True, (255, 100, 0))
        textInfo2 = smallfont.render(f'Version: {version}', True, color)
        textInfo3 = smallfont.render('Dieses Programm wurde von Tobias Auer programmiert', True, color)

        # symbols
        symbol_button = button.Button(0, 0, symbol,
                                      (formel / 5000), 0)
        symbol_button2 = button.Button(int(surface.get_width()), 0, symbol, (formel / 5000), 1)
        symbol_button3 = button.Button(0, int(surface.get_height()), symbol2,
                                       (formel / 700), 7)
        symbol_button4 = button.Button(int(surface.get_width()), int(surface.get_height()), symbol2,
                                       (formel / 700), 8)

        ok_button = button.Button(int(surface.get_width()) / 2, int(surface.get_height() / 1.2), beenden_img,
                                  (formel / 1000))
        ok_button2 = button.Button(int(surface.get_width()) / 2, int(surface.get_height() / 1.2), beenden2_img,
                                   (formel / 1000))
        # symbols
        textInfo4 = smallfont.render('Websites:', True, color)
        textRectInfo1 = textInfo1.get_rect()
        textRectInfo2 = textInfo2.get_rect()
        textRectInfo3 = textInfo3.get_rect()
        textRectInfo4 = textInfo4.get_rect()

        surface.fill((25, 50, 10))

        textRectInfo1.center = (int(surface.get_width()) / 2, int(surface.get_height() / 5))
        textRectInfo2.center = (int(surface.get_width()) / 2, int(surface.get_height() / 4))
        textRectInfo3.center = (int(surface.get_width()) / 2, int(surface.get_height() / 3))
        textRectInfo4.center = (int(surface.get_width()) / 2, int(surface.get_height() / 2))

        while infos:
            surface.fill((25, 50, 10))
            if ok_button.draw(surface)[0]:
                infos = False
            if ok_button.draw(surface)[1]:
                ok_button2.draw(surface)
            symbol_button.draw(surface)
            symbol_button2.draw(surface)
            symbol_button3.draw(surface)
            symbol_button4.draw(surface)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    infos = False
            surface.blit(textInfo1, textRectInfo1)
            surface.blit(textInfo2, textRectInfo2)
            surface.blit(textInfo3, textRectInfo3)
            surface.blit(textInfo4, textRectInfo4)
            pygame.display.update()
