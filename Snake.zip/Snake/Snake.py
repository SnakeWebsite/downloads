import sys
import pygame
from pygame.constants import FULLSCREEN
import shop
import contact
import credits
import fos
import snakeBasis
import button
import skinsystem


version = 1.1


class Main:

    def __init__(self):
        # init the window
        self.fenster = pygame.display.set_mode((0, 0), FULLSCREEN)
        try:
            self.money = fos.Read.do()
        except IndexError:
           self.money = "ERROR: IndexError"
        try:
            self.rang = fos.Read.do(line=1)
        except IndexError:
            self.rang = "ERROR: IndexError"
        try:
            self.highscore = fos.Read.do(line=3)
        except IndexError:
            self.highscore = "ERROR: IndexError"
        try:
            self.skin = int(fos.Read.do(line=2))
        except IndexError:
            fos.Oho()
            print("OK")

        #self.skin=-1

        # init some things like font
        self.running = True

        self.formel = int(self.fenster.get_width() + self.fenster.get_height() / 125)
        self.color = (255, 255, 255)
        self.schriftgroesse = int((self.fenster.get_width() + self.fenster.get_height()) / 71)
        print(self.schriftgroesse)
        self.smallfont = pygame.font.SysFont('italic', self.schriftgroesse)

        # init pictures
        self.cart_img = pygame.image.load("bilder\cart.png").convert_alpha()
        self.cart_img2 = pygame.image.load("bilder\cart2.png").convert_alpha()
        self.start_img    = pygame.image.load("bilder\start-button.png").convert_alpha()
        self.start_img2   = pygame.image.load("bilder\start-button2.png").convert_alpha()
        self.minus_img    = pygame.image.load("bilder\minus.png").convert_alpha()
        self.minus_img2   = pygame.image.load("bilder\minus2.png").convert_alpha()
        self.beenden_img  = pygame.image.load(r"bilder\x.png").convert_alpha()
        self.beenden2_img = pygame.image.load(r"bilder\x2.png").convert_alpha()
        self.frage_img    = pygame.image.load("bilder\question.png").convert_alpha()
        self.frage2_img   = pygame.image.load("bilder\question2.png").convert_alpha()
        self.message = pygame.image.load(r"bilder\blase1.png").convert_alpha()
        self.message2 = pygame.image.load(r"bilder\blase2.png").convert_alpha()
        self.setting_img = pygame.image.load("bilder\setting.png").convert_alpha()
        self.setting2_img = pygame.image.load("bilder\setting2.png").convert_alpha()

        # init text
        self.text_for_basis_snake = "Klassischer Spielmodi\nSchwierigkeit: Leicht\nGeschwindigkeit: " \
                                    "Mittel\nBesonderheiten: Keine\nSteuerung: Pfeiltasten\n\n" \
                                    "Der altbekannte originale Spielmodi,es müssen " \
                                    "die immer wieder erscheinenden Punkte eingesammelt werden um größer zu " \
                                    "werden\n\n\nAchtung:\n\nWenn du den Rand oder dich selber berührst, ist es " \
                                    "vorbei!\n\nViel Spaß!"
        self.text_do_sth = f"Fahre mit dem Mauszeiger über einen Button, um weitere Informationen anzuzeigen!"
        self.text_money = f"Du besitzt {self.money} Punkte.            Dein aktueller Rang ist: {self.rang}            Dein High Score ist: {self.highscore}"

        # init the buttons
        self.start_button = button.Button(int(self.fenster.get_width()) / 2, int(self.fenster.get_height() / 1.7),
                                          self.start_img,
                                          (self.formel / 1000), 1)
        self.start_button2 = button.Button(int(self.fenster.get_width() / 2), int(self.fenster.get_height() / 1.7),
                                           self.start_img2,
                                           self.formel / 1000, 1)
        self.minus_button = button.Button(
            int(self.fenster.get_width() - self.beenden_img.get_width() * (self.formel / 800) * 1.7), 0,
            self.minus_img, (self.formel / 800), 3)
        self.minus_button2 = button.Button(
            int(self.fenster.get_width() - self.beenden_img.get_width() * (self.formel / 800) * 1.7), 0,
            self.minus_img2, (self.formel / 800), 3)
        self.beenden_button = button.Button(int(self.fenster.get_width()), 0, self.beenden_img, self.formel / 800, 1)
        self.beenden2_button = button.Button(int(self.fenster.get_width()), 0, self.beenden2_img, self.formel / 800, 1)
        self.question_button = button.Button(
            int(self.fenster.get_width() - self.minus_img.get_width() * (self.formel / 800) * 2), 0,
            self.frage_img, self.formel / 30000, 1)
        self.question2_button = button.Button(
            int(self.fenster.get_width() - self.minus_img.get_width() * (self.formel / 800) * 2), 0,
            self.frage2_img, self.formel / 30000, 1)
        self.message_button = button.Button(
            int(self.fenster.get_width() - self.minus_img.get_width() * (self.formel / 800) * 3), 0,
            self.message, self.formel / 7000, 1)
        self.message_button2 = button.Button(
            int(self.fenster.get_width() - self.minus_img.get_width() * (self.formel / 800) * 3), 0,
            self.message2, self.formel / 7000, 1)
        self.cart_button = button.Button(
            int(self.fenster.get_width() - self.minus_img.get_width() * (self.formel / 800) * 4.5), 0,
            self.cart_img, self.formel / 4300, 1)
        self.cart_button2 = button.Button(
            int(self.fenster.get_width() - self.minus_img.get_width() * (self.formel / 800) * 4.5), 0,
            self.cart_img2, self.formel / 4300, 1)
        self.setting_button = button.Button(int(self.fenster.get_width()) / 2, int(self.fenster.get_height() / 1.7),
                                          self.setting_img,
                                          (self.formel / 10000), 0)
        self.setting_button2 = button.Button(int(self.fenster.get_width() / 2), int(self.fenster.get_height() / 1.7),
                                           self.setting2_img,
                                           self.formel / 10000, 0)
        self.main()

    # check the buttons
    def checkbuttons(self):

        if self.start_button.draw(self.fenster, secure=True)[0]:
            snakeBasis.Start(self.skin)
        if self.start_button.draw(self.fenster)[1]:
            self.start_button2.draw(self.fenster)
            self.blit_text(self.fenster, self.text_for_basis_snake, (20, 100), self.smallfont, color=self.color)
        else:
            self.blit_text(self.fenster, self.text_do_sth, (20, self.fenster.get_height() // 2), self.smallfont,
                           color=(100, 255, 40))

        if self.beenden_button.draw(self.fenster, secure=True)[0]:
            self.running = False
        if self.beenden_button.draw(self.fenster, secure=True)[1]:
            self.beenden2_button.draw(self.fenster)

        if self.minus_button.draw(self.fenster, secure=True)[0]:
            pygame.display.iconify()
        if self.minus_button.draw(self.fenster)[1]:
            self.minus_button2.draw(self.fenster)

        if self.message_button.draw(self.fenster, secure=True)[0]:
            contact.Contact(self.fenster)
        if self.message_button.draw(self.fenster)[1]:
            self.message_button2.draw(self.fenster)

        if self.question_button.draw(self.fenster, secure=True)[0]:
            credits.Credits(self.fenster, version, (255, 255, 255))
        if self.question_button.draw(self.fenster)[1]:
            self.question2_button.draw(self.fenster)

        if self.cart_button.draw(self.fenster, secure=True)[0]:
            shop.Shop(self.fenster)
        if self.cart_button.draw(self.fenster)[1]:
            self.cart_button2.draw(self.fenster)

        if self.setting_button.draw(self.fenster, secure=True)[0]:
            skinsystem.SkinSystem(self.fenster)
        if self.setting_button.draw(self.fenster)[1]:
            self.setting_button2.draw(self.fenster)

    # draw the buttons
    def draw(self):
        self.start_button.draw(self.fenster)
        self.beenden_button.draw(self.fenster)
        self.minus_button.draw(self.fenster)
        self.question_button.draw(self.fenster)
        self.cart_button.draw(self.fenster)

    # draw the text
    def blit_text(self, surface, text, pos, font, color=pygame.Color('black')):
        words = [word.split(' ') for word in text.splitlines()]  # 2D array where each row is a list of words.
        space = font.size(' ')[0]  # The width of a space.
        max_width, max_height = abs(self.start_button.rect.x - 10), surface.get_height()
        x, y = pos
        for line in words:
            for word in line:
                word_surface = font.render(word, 0, color)
                word_width, word_height = word_surface.get_size()
                if x + word_width >= max_width:
                    x = pos[0]  # Reset the x.
                    y += word_height  # Start on new row.
                surface.blit(word_surface, (x, y))
                x += word_width + space
            x = pos[0]  # Reset the x.
            y += word_height  # Start on new row.

    def main(self):
        pygame.display.set_caption("Snake")
        a = self.smallfont.render(self.text_money, (0,0), self.color)
        textRect = a.get_rect()
        textRect.topleft = (0,0)

        while self.running:
            self.fenster.fill((5, 30, 100))
            self.fenster.blit(a, textRect)
            self.draw()
            self.checkbuttons()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            pygame.display.update()
            pygame.display.flip()
        sys.exit()


if __name__ == "__main__":
    pygame.init()
    Main()
