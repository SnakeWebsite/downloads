import random
import time
import tkinter
import sys
import pygame
from enum import Enum
from pygame.constants import FULLSCREEN

import Snake
import fos

def highscore(scores):
    print(scores)
    fos.Write.do(scores)
    fos.Write.do(value=scores, line=3, mode="highest")


class Start:

    def __init__(self, skin):
        self.a = None
        self.randomlist = []
        self.randomlist2 = []
        self.game_loop(skin)

    def handle_keys(self, direction):
        new_direction = direction
        for event in [e for e in pygame.event.get() if e.type == pygame.KEYDOWN]:
            if event.key == pygame.K_UP and direction != self.Direction.DOWN:
                new_direction = self.Direction.UP
            if event.key == pygame.K_DOWN and direction != self.Direction.UP:
                new_direction = self.Direction.DOWN
            if event.key == pygame.K_RIGHT and direction != self.Direction.LEFT:
                new_direction = self.Direction.RIGHT
            if event.key == pygame.K_LEFT and direction != self.Direction.RIGHT:
                new_direction = self.Direction.LEFT
        return new_direction

    class Direction(Enum):
        UP = 1
        DOWN = 2
        RIGHT = 3
        LEFT = 4

    speed = 12

    pygame.init()
    pygame.display.set_caption("Snake")
    window = pygame.display.set_mode((0, 0), FULLSCREEN, pygame.NOFRAME)

    refresh_controller = pygame.time.Clock()

    snake_position = [250, 250]
    snake_body = [[250, 250],
                  [240, 250],
                  [230, 250]
                  ]

    food_position = [100, 100]
    window_width, window_height = window.get_size()
    scale = int((window_width + window_height) / 125)

    score = 0

    def move_snake(self, direction):
        if direction == self.Direction.UP:
            self.snake_position[1] -= self.scale
        if direction == self.Direction.DOWN:
            self.snake_position[1] += self.scale
        if direction == self.Direction.LEFT:
            self.snake_position[0] -= self.scale
        if direction == self.Direction.RIGHT:
            self.snake_position[0] += self.scale
        self.snake_body.insert(0, list(self.snake_position))

    def generate_new_food(self):
        # global food_position
        self.food_position[0] = random.randint(5, ((window_width - 2) // self.scale)) * self.scale
        self.food_position[1] = random.randint(5, ((window_height - 2) // self.scale)) * self.scale
        # global snake_body
        # for food_position in snake_body:
        #     if food_position[0] == snake_body[0] and food_position[1] == snake_body[1]:
        #         print("AHA")

    def get_food(self):
        pass

    def repaint(self, skin):  # ==============================================================================================
        global a
        # set background
        self.window.fill(pygame.Color(0, 0, 0))
        #draw food
        food = pygame.draw.rect(self.window, pygame.Color(255, 0, 0),
                                pygame.Rect(self.food_position[0] - self.scale / 2,
                                            self.food_position[1] - self.scale,
                                            self.scale, self.scale))
        food.topleft = self.food_position[0], self.food_position[1]

        #draw snake
        if skin==0:
            pass
        elif skin == 1:
            for body in self.snake_body[:1]:
                a = pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
            for body in self.snake_body[1:]:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        # ------------------ #
        elif skin == 2:
            for body in self.snake_body[:1]:
                a = pygame.draw.circle(self.window, pygame.Color(0, 191, 255), (body[0], body[1]), self.scale / 2)
            for body in self.snake_body[1:]:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        elif skin==3:
            for body in self.snake_body[:1]:
                a = pygame.draw.circle(self.window, pygame.Color(255, 50, 50), (body[0], body[1]), self.scale / 2)
            for body in self.snake_body[1:]:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        elif skin==4:
            for body in self.snake_body[:1]:
                a = pygame.draw.circle(self.window, pygame.Color(255, 0, 136), (body[0], body[1]), self.scale / 2)
            for body in self.snake_body[1:]:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        # ------------------ #
        elif skin==5:
            self.temp2=self.snake_body[:]
            for body in self.snake_body[::3]:
                a = pygame.draw.circle(self.window, pygame.Color(0, 191, 255), (body[0], body[1]), self.scale / 2)
                self.temp2.remove(body)
            for body in self.temp2:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        elif skin==6:
            self.temp2=self.snake_body[:]
            for body in self.snake_body[::3]:
                a = pygame.draw.circle(self.window, pygame.Color(255, 50, 50), (body[0], body[1]), self.scale / 2)
                self.temp2.remove(body)
            for body in self.temp2:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        elif skin==7:
            self.temp2=self.snake_body[:]
            for body in self.snake_body[::3]:
                a = pygame.draw.circle(self.window, pygame.Color(255, 0, 136), (body[0], body[1]), self.scale / 2)
                self.temp2.remove(body)
            for body in self.temp2:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        # ------------------ #
        elif skin==8:
            self.temp2=self.snake_body[:]
            for body in self.snake_body[::2]:
                a = pygame.draw.circle(self.window, pygame.Color(0, 191, 255), (body[0], body[1]), self.scale / 2)
                self.temp2.remove(body)
            for body in self.temp2:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        elif skin==9:
            self.temp2=self.snake_body[:]
            for body in self.snake_body[::2]:
                a = pygame.draw.circle(self.window, pygame.Color(255, 50, 50), (body[0], body[1]), self.scale / 2)
                self.temp2.remove(body)
            for body in self.temp2:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        elif skin==10:
            self.temp2=self.snake_body[:]
            for body in self.snake_body[::2]:
                a = pygame.draw.circle(self.window, pygame.Color(255, 0, 136), (body[0], body[1]), self.scale / 2)
                self.temp2.remove(body)
            for body in self.temp2:
                pygame.draw.circle(self.window, pygame.Color(50, 255, 50), (body[0], body[1]), self.scale / 2)
        # ------------------ #
        elif skin == 11:
            for body in self.snake_body:
                pygame.draw.circle(self.window, pygame.Color(0, 191, 255), (body[0], body[1]), self.scale / 2)
        elif skin == 12:
            for body in self.snake_body:
                pygame.draw.circle(self.window, pygame.Color(255, 50, 50), (body[0], body[1]), self.scale / 2)
        elif skin == 13:
            for body in self.snake_body:
                pygame.draw.circle(self.window, pygame.Color(255, 0, 136), (body[0], body[1]), self.scale / 2)
        # ------------------ #
        elif skin == 14:
            index_of_loop=0
            for body in self.snake_body:
                pygame.draw.circle(self.window, pygame.Color(0, 191, 255), (body[0], body[1]), self.scale / 2)
            for body in self.snake_body[::3]:
                if index_of_loop not in self.randomlist:
                    a, b, c = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
                    pygame.draw.circle(self.window, pygame.Color(a, b, c), (body[0], body[1]), self.scale / 2)
                    self.randomlist.append(index_of_loop)
                    self.randomlist2.append([a, b, c])
                else:
                    pygame.draw.circle(self.window, pygame.Color(self.randomlist2[index_of_loop][0],
                                                                 self.randomlist2[index_of_loop][1],
                                                                 self.randomlist2[index_of_loop][2]),
                                       (body[0], body[1]), self.scale / 2)
                index_of_loop += 1
        elif skin == 15:
            for body in self.snake_body:
                index_of_loop = 0
                for body in self.snake_body:
                    pygame.draw.circle(self.window, pygame.Color(255, 50, 50), (body[0], body[1]), self.scale / 2)
                for body in self.snake_body[::3]:
                    if index_of_loop not in self.randomlist:
                        a, b, c = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
                        pygame.draw.circle(self.window, pygame.Color(a, b, c), (body[0], body[1]), self.scale / 2)
                        self.randomlist.append(index_of_loop)
                        self.randomlist2.append([a, b, c])
                    else:
                        pygame.draw.circle(self.window, pygame.Color(self.randomlist2[index_of_loop][0],
                                                                     self.randomlist2[index_of_loop][1],
                                                                     self.randomlist2[index_of_loop][2]),
                                           (body[0], body[1]), self.scale / 2)
                    index_of_loop += 1
        elif skin == 16:
            for body in self.snake_body:
                index_of_loop = 0
                for body in self.snake_body:
                    pygame.draw.circle(self.window, pygame.Color(255, 0, 136), (body[0], body[1]), self.scale / 2)
                for body in self.snake_body[::3]:
                    if index_of_loop not in self.randomlist:
                        a, b, c = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
                        pygame.draw.circle(self.window, pygame.Color(a, b, c), (body[0], body[1]), self.scale / 2)
                        self.randomlist.append(index_of_loop)
                        self.randomlist2.append([a, b, c])
                    else:
                        pygame.draw.circle(self.window, pygame.Color(self.randomlist2[index_of_loop][0],
                                                                     self.randomlist2[index_of_loop][1],
                                                                     self.randomlist2[index_of_loop][2]),
                                           (body[0], body[1]), self.scale / 2)
                    index_of_loop += 1
        # ------------------ #
        elif skin == 17:
            index_of_loop=0
            for body in self.snake_body:
                pygame.draw.circle(self.window, pygame.Color(0, 191, 255), (body[0], body[1]), self.scale / 2)
            for body in self.snake_body[::2]:
                if index_of_loop not in self.randomlist:
                    a, b, c = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
                    pygame.draw.circle(self.window, pygame.Color(a, b, c), (body[0], body[1]), self.scale / 2)
                    self.randomlist.append(index_of_loop)
                    self.randomlist2.append([a, b, c])
                else:
                    pygame.draw.circle(self.window, pygame.Color(self.randomlist2[index_of_loop][0],
                                                                 self.randomlist2[index_of_loop][1],
                                                                 self.randomlist2[index_of_loop][2]),
                                       (body[0], body[1]), self.scale / 2)
                index_of_loop += 1
        elif skin == 18:
            for body in self.snake_body:
                index_of_loop = 0
                for body in self.snake_body:
                    pygame.draw.circle(self.window, pygame.Color(255, 50, 50), (body[0], body[1]), self.scale / 2)
                for body in self.snake_body[::2]:
                    if index_of_loop not in self.randomlist:
                        a, b, c = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
                        pygame.draw.circle(self.window, pygame.Color(a, b, c), (body[0], body[1]), self.scale / 2)
                        self.randomlist.append(index_of_loop)
                        self.randomlist2.append([a, b, c])
                    else:
                        pygame.draw.circle(self.window, pygame.Color(self.randomlist2[index_of_loop][0],
                                                                     self.randomlist2[index_of_loop][1],
                                                                     self.randomlist2[index_of_loop][2]),
                                           (body[0], body[1]), self.scale / 2)
                    index_of_loop += 1
        elif skin == 19:
            for body in self.snake_body:
                index_of_loop = 0
                for body in self.snake_body:
                    pygame.draw.circle(self.window, pygame.Color(255, 0, 136), (body[0], body[1]), self.scale / 2)
                for body in self.snake_body[::2]:
                    if index_of_loop not in self.randomlist:
                        a, b, c = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
                        pygame.draw.circle(self.window, pygame.Color(a, b, c), (body[0], body[1]), self.scale / 2)
                        self.randomlist.append(index_of_loop)
                        self.randomlist2.append([a, b, c])
                    else:
                        pygame.draw.circle(self.window, pygame.Color(self.randomlist2[index_of_loop][0],
                                                                     self.randomlist2[index_of_loop][1],
                                                                     self.randomlist2[index_of_loop][2]),
                                           (body[0], body[1]), self.scale / 2)
                    index_of_loop += 1
        # ------------------ #
        elif skin == 20:
            index_of_loop=0
            for body in self.snake_body:
                if index_of_loop not in self.randomlist:
                    a,b,c = random.randint(0,255), random.randint(0,255), random.randint(0,255)
                    pygame.draw.circle(self.window, pygame.Color(a,b,c), (body[0], body[1]), self.scale / 2)
                    self.randomlist.append(index_of_loop)
                    self.randomlist2.append([a,b,c])
                else:
                    pygame.draw.circle(self.window, pygame.Color(self.randomlist2[index_of_loop][0],self.randomlist2[index_of_loop][1],self.randomlist2[index_of_loop][2]), (body[0], body[1]), self.scale / 2)
                index_of_loop+=1
            # print(self.randomlist)
            # print(self.randomlist2)

        elif skin ==21:
            for body in self.snake_body:
                pygame.draw.circle(self.window, pygame.Color(random.randint(0,255), random.randint(0,255), random.randint(0,255)), (body[0], body[1]), self.scale / 2)
        elif skin == -1:  # Special Skin
            a,b,c = random.randint(0,255), random.randint(0,255), random.randint(0,255)
            for body in self.snake_body:
                pygame.draw.circle(self.window, pygame.Color(a,b,c), (body[0], body[1]), self.scale / 2)
        # ------------------ #
        else:
            fos.Oho()

        # food check
        if abs(self.snake_position[0] - self.food_position[0]) < (self.scale * 0.75) and abs(
                self.snake_position[1] + (self.scale / 2) - self.food_position[1]) < (self.scale * 0.75):
            self.score += 1
            self.generate_new_food()
        else:
            self.snake_body.pop()

    def game_over_message(self):
        font = pygame.font.SysFont("Arial", self.scale * 4)
        render = font.render(f"Score: {self.score}", True, pygame.Color(255, 255, 255))
        rect = render.get_rect()
        rect.midtop = (self.window_width / 2, window_height / 2)
        self.window.blit(render, rect)
        pygame.display.flip()
        time.sleep(5)
        highscore(self.score)

        self.score = 0
        print("score" + str(self.score))

        self.snake_position = [250, 250]
        print(self.snake_position)
        self.snake_body = [[250, 250],
                  [240, 250],
                  [230, 250]
                  ]
        print(self.snake_body)
        self.food_position = [100, 100]
        pygame.mouse.set_visible(True)
        Snake.Main()

    def game_over(self):
        if self.snake_position[0] < 10 or self.snake_position[0] > self.window_width - 10:
            self.game_over_message()
        if self.snake_position[1] < 10 or self.snake_position[1] > self.window_height - 10:
            self.game_over_message()
        if self.snake_position in self.snake_body[1:]:
            self.game_over_message()

    def paint_hud(self):
        font = pygame.font.SysFont("Arial", self.scale * 2)
        render = font.render(
            f"Score: {self.score}",
            True, pygame.Color(255, 255, 255))
        rect = render.get_rect()
        self.window.blit(render, rect)
        pygame.display.flip()

    def game_loop(self, skin):
        global window_width, window_height
        pygame.mouse.set_visible(False)
        direction = self.Direction.RIGHT
        self.score = 0
        print("score" + str(self.score))

        self.snake_position = [250, 250]
        print(self.snake_position)
        self.snake_body = [[250, 250],
                  [240, 250],
                  [230, 250]
                  ]
        print(self.snake_body)
        self.food_position = [100, 100]
        while True:
            window_width, window_height = self.window.get_size()
            direction = self.handle_keys(direction)
            self.move_snake(direction)
            self.get_food()
            self.repaint(skin)
            self.game_over()
            self.paint_hud()
            pygame.display.update()
            self.refresh_controller.tick(self.speed)


if __name__ == '__main__':
    Start()
